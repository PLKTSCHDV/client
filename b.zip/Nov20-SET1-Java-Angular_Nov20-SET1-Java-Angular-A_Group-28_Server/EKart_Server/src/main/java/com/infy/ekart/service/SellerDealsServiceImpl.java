package com.infy.ekart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.infy.ekart.dto.DealDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.Deal;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.SellerDealsRepository;
import com.infy.ekart.repository.SellerRepository;

@Service(value = "sellerDealService")
@Transactional
public class SellerDealsServiceImpl implements SellerDealsService {
	@Autowired
	private SellerDealsRepository dealRepository;

	@Autowired
	private SellerRepository sellerRepo;

	// This method will retrieve list of all the products from database

	@Override
	public Integer addDeals(DealDTO dt) throws EKartException {

		Optional<Seller> os = sellerRepo.findById(dt.getSellerEmailId());
		Seller s = os.orElseThrow(() -> new EKartException("Service.SELLER_NOT_FOUND"));

		List<Deal> dealList = s.getDeal();

		Deal d = new Deal();

		d.setDealDiscount(dt.getDealDiscount());
		d.setDealEnds(dt.getDealEnds());
		d.setDealStarts(dt.getDealStarts());

		ProductDTO prod = dt.getProduct();
		Product prodDto = new Product();

		prodDto.setBrand(prod.getBrand());
		prodDto.setCategory(prod.getCategory());
		prodDto.setDescription(prod.getDescription());
		prodDto.setDiscount(prod.getDiscount());
		prodDto.setName(prod.getName());
		prodDto.setPrice(prod.getPrice());
		prodDto.setQuantity(prod.getQuantity());
		prodDto.setSellerEmailId(prod.getSellerEmailId());
		prodDto.setProductId(prod.getProductId());

		d.setProduct(prodDto);
		if (dealList.isEmpty())
			dealList = new ArrayList<Deal>();
		dealList.add(d);

		Deal deal = dealRepository.save(d);
		s.setDeal(dealList);
		return deal.getDealId();
	}

	@Override
	public List<ProductDTO> getNonDeals(String sellerEmailId) throws EKartException {
	System.out.println("email : "+sellerEmailId);
	//	sellerEmailId+=".com";
	System.out.println("email : "+sellerEmailId);
		List<Product> productEntities = dealRepository.findBySellerEmailIdEqualsAndDealStartsAfter(sellerEmailId);

		List<ProductDTO> pol = new ArrayList<ProductDTO>();
		for (Product p : productEntities) {
			ProductDTO pd = new ProductDTO();
			pd.setBrand(p.getBrand());
			pd.setCategory(p.getCategory());
			pd.setDescription(p.getDescription());
			pd.setDiscount(p.getDiscount());
			pd.setName(p.getName());
			pd.setPrice(p.getPrice());
			pd.setQuantity(p.getQuantity());
			pd.setSellerEmailId(p.getSellerEmailId());
			pd.setProductId(p.getProductId());
			pol.add(pd);
		}
		return pol;
	}

	// US02 get all products by Rahul 
	@Override
	public List<DealDTO> getAllProducts(String sellerEmailId) throws EKartException {
		//PageRequest.of(pageNo, 10);

		Optional<Seller> os = sellerRepo.findById(sellerEmailId);
		Seller s = os.orElseThrow(() -> new EKartException("Service.SELLER_NOT_FOUND"));

		List<Deal> dealList = s.getDeal();

		List<DealDTO> dealDTO = new ArrayList<DealDTO>();

		dealList.forEach(d -> {
			DealDTO dto = new DealDTO();

			dto.setDealDiscount(d.getDealDiscount());
			dto.setDealEnds(d.getDealEnds());
			dto.setDealStarts(d.getDealStarts());
			dto.setDealId(d.getDealId());
			dto.setSellerEmailId(sellerEmailId);

			Product prod = d.getProduct();
			ProductDTO prodDto = new ProductDTO();

			prodDto.setBrand(prod.getBrand());
			prodDto.setCategory(prod.getCategory());
			prodDto.setDescription(prod.getDescription());
			prodDto.setDiscount(prod.getDiscount());
			prodDto.setName(prod.getName());
			prodDto.setPrice(prod.getPrice());
			prodDto.setQuantity(prod.getQuantity());
			prodDto.setSellerEmailId(prod.getSellerEmailId());
			prodDto.setProductId(prod.getProductId());

			dto.setProduct(prodDto);

			dealDTO.add(dto);

		});

		return dealDTO;

	}
	@Override
	public Integer deleteDeals(Integer dealId) throws EKartException {

	    Optional<Deal> dl=dealRepository.findById(dealId);
		Deal d=dl.orElseThrow(()->new EKartException("Deal cannot be deleted"));
		//Deal d=new Deal();
		d.setProduct(null);
		dealRepository.deleteById(dealId);

		return dealId;
	}

}
