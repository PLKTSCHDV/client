package com.infy.ekart.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infy.ekart.entity.Deal;
import com.infy.ekart.entity.Product;
@Repository
public interface SellerDealsRepository extends CrudRepository<Deal, Integer> {

//	@Query("select pe from Product pe where pe.productId not in" + "(select de.product.productId from Deal de)" + "and pe.sellerEmailId=:sellerEmailId" )
//	List<Product> findBySellerEmailIdEqualsAndDealStartsAfter(@Param("sellerEmailId") String sellerEmailId);
	
	@Query("select pe from Product pe where pe.sellerEmailId=:sellerEmailId and pe.productId not in (select de.product.productId "
			+ "from Deal de where de.sellerEmailId=:sellerEmailId and  de.dealStarts > current_timestamp) " )
	List<Product> findBySellerEmailIdEqualsAndDealStartsAfter(@Param("sellerEmailId") String sellerEmailId);
	
	@Query("select d from Deal d where CAST(d.dealStarts as LocalDate)= :today")
	List<Deal> getProducts(LocalDate today);
	/*
	 select * from ek_product where seller_email_id='jack@infosys.com' and product_id not in (select product_id from ek_deals_for_today where seller_email_id = 'jack@infosys.com' and deal_starts_At > current_timestamp);
	 */
	
	/*
	@Query(value="select * from Product P where seller_email_id = ?1 and P.product_id not in (select D.product_id from ek_deals_for_today D where D.seller_email_id = ?1 and D.DEAL_ENDS_AT < Current_Timestamp)",nativeQuery=true)
	
	public List<Deal> findBySellerEmailId(@Param(value = "sellerEmailId") String sellerEmailId, Pageable pageable);
	*/
	
	/*
	@Query(value="select * from Deal D where D.sellerEmailId = :email and D.dealStarts > CURRENT_TIMESTAMP", nativeQuery = true)
	public List<Deal> findNonDeal(@Param("email") String sellerEmail);
	
	*/

	
}