package com.infy.ekart.service;

import java.util.List;
import java.util.Set;

import com.infy.ekart.dto.DealDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.exception.EKartException;

public interface SellerDealsService {

	Integer addDeals(DealDTO dealDTO) throws EKartException;

	List<DealDTO> getAllProducts(String sellerEmailId) throws EKartException;
	
	List<ProductDTO> getNonDeals(String sellerEmailId) throws EKartException;

	Integer deleteDeals(Integer dealId) throws EKartException;
}
