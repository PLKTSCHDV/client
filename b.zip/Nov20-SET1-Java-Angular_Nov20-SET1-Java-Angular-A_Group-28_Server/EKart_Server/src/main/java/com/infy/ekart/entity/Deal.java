package com.infy.ekart.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "EK_DEALS_FOR_TODAY")
public class Deal {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DEAL_ID")
	private Integer dealId;

	/*
	 * @ManyToOne(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name = "PRODUCT_ID")
	 */
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "PRODUCT_ID")
	private Product product;

	@Column(name = "DEAL_DISCOUNT")
	private Double dealDiscount;

	@Column(name = "DEAL_STARTS_AT")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", shape = JsonFormat.Shape.STRING)
	private LocalDateTime dealStarts;

	@Column(name = "DEAL_ENDS_AT")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", shape = JsonFormat.Shape.STRING)
	private LocalDateTime dealEnds;
	
	@Column(name = "SELLER_EMAIL_ID")
	private String sellerEmailId;
	
	

	public String getSellerEmailId() {
		return sellerEmailId;
	}

	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}

	public Integer getDealId() {
		return dealId;
	}

	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}

	public Double getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(Double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}

	public LocalDateTime getDealStarts() {
		return dealStarts;
	}

	public void setDealStarts(LocalDateTime dealStarts) {
		this.dealStarts = dealStarts;
	}

	public LocalDateTime getDealEnds() {
		return dealEnds;
	}

	public void setDealEnds(LocalDateTime dealEnds) {
		this.dealEnds = dealEnds;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}
