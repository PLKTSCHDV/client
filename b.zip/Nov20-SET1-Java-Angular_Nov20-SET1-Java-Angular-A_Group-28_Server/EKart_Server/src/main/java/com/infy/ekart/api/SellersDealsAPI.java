package com.infy.ekart.api;

import java.util.List;
import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.DealDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.service.SellerDealsService;

@CrossOrigin
@RestController
@RequestMapping(value = "/sellersDeal-api")
@Validated
public class SellersDealsAPI {

	@Autowired
	private SellerDealsService sellerDealsService;

	static Log logger = LogFactory.getLog(SellersDealsAPI.class);

	@PostMapping(value = "/add-deals")
	public ResponseEntity<String> addDeals(@Valid @RequestBody DealDTO dealDTO) throws EKartException {

		logger.info("ADDING PRODUCTS TO DEAL. PRODUCTS QUANTITY: " + dealDTO.getDealId());
		Integer addedToDeal = sellerDealsService.addDeals(dealDTO);
		String msg = "Product successfully added to deal with dealId : " + addedToDeal;
		return new ResponseEntity<>(msg, HttpStatus.OK);

	}
    @CrossOrigin
	@GetMapping(value = "{sellerEmailId}/get-deals")
	public ResponseEntity<List<DealDTO>> getDealDTO(@PathVariable("sellerEmailId") String sellerEmail) throws EKartException {
		List<DealDTO> prodDto = sellerDealsService.getAllProducts(sellerEmail);

		return new ResponseEntity<List<DealDTO>>(prodDto, HttpStatus.OK);
	}

	@GetMapping("{sellerEmailId}/get-nondeals")
	public ResponseEntity getNonDeal(@PathVariable String sellerEmailId) throws EKartException {
		try {
			List<ProductDTO> prodList = sellerDealsService.getNonDeals(sellerEmailId);
			if (prodList.isEmpty()) {
				return new ResponseEntity<String>("No products which are not on deals already", HttpStatus.OK);
			} else {
				return new ResponseEntity<List<ProductDTO>>(prodList, HttpStatus.OK);
			}
 
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

//	Done by nikita
	@DeleteMapping("delete-deal/{dealId}")
	public ResponseEntity<String> removeDeal(@PathVariable("dealId") Integer dealId) throws EKartException {
		Integer id = sellerDealsService.deleteDeals(dealId);
		String msg = "Deal with DealId: " + id + " successfuly removed.";

		return new ResponseEntity<String>(msg, HttpStatus.OK);

	}

}
