package com.infy.ekart.dto;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

public class DealDTO {

	private Integer dealId;
	private ProductDTO product;
	@NotNull
	private Double dealDiscount;
	@NotNull
	private LocalDateTime dealStarts;
	@NotNull
	private LocalDateTime dealEnds;
	private String sellerEmailId;

	public Integer getDealId() {
		return dealId;
	}

	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}

	public ProductDTO getProduct() {
		return product;
	}

	public void setProduct(ProductDTO product) {
		this.product = product;
	}

	public Double getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(Double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}

	public LocalDateTime getDealStarts() {
		return dealStarts;
	}

	public void setDealStarts(LocalDateTime dealStarts) {
		this.dealStarts = dealStarts;
	}

	public LocalDateTime getDealEnds() {
		return dealEnds;
	}

	public void setDealEnds(LocalDateTime dealEnds) {
		this.dealEnds = dealEnds;
	}

	public String getSellerEmailId() {
		return sellerEmailId;
	}

	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}

}
