import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
//import { environment } from '../../../../../environments/environment';
//import { Product } from '../../../../shared/models/product';
import { catchError } from 'rxjs/internal/operators/catchError';
import { Product } from 'src/src/app/shared/models/product';
import { environment } from 'src/environments/environment';
import { dealsProduct } from './shared/models/dealsProduct';

@Injectable({
  providedIn: 'root'
})
export class DealServiceService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http:HttpClient) { }
  
  /*addToDeals(product:Product):Observable<any>{
    return this.http.post("",product);
  }*/
  addToDeals(deal:dealsProduct):Observable<dealsProduct>{
    const url = environment.sellersDealAPI + "/add-deals";
    console.log(JSON.stringify(deal))

    return this.http.post<dealsProduct>(url, deal)  

    //return this.http.post<dealsProduct>("https://localhost:3333/EKart_Server/sellersDeal-api/add-deals", deal)  
  }
  getProducts(emailId : any) {
    const url = environment.sellersDealAPI + "/" + emailId + "/get-nondeals"  ;
  
    return this.http.get<Product[]>(url);

    //return this.http.get<Product[]>("http://localhost:3333/EKart_Server/sellersDeal-api/jack@infosys.com/get-nondeals");

  }
 //getProductCategories(): Observable<string[]> {
   // return this.http.get<string[]>("https://localhost:3333//EKart_Server/sellersDeal-api/deals");
  //}

  //message:String=""
  

  
}
