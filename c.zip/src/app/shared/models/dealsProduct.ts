import { Product } from './product';

export class dealsProduct {
    dealId : number;
	successMessage: string;
	errorMessage:string;
	sellerEmailId : string;
	product : Product;
	dealDiscount : number;
	dealStarts : Date;
	dealEnds : Date

}
