import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerDealsForTodayComponent } from './seller-deals-for-today.component';

describe('SellerDealsForTodayComponent', () => {
  let component: SellerDealsForTodayComponent;
  let fixture: ComponentFixture<SellerDealsForTodayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SellerDealsForTodayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerDealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
