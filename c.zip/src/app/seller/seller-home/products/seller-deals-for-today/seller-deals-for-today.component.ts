import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { getLocaleDateTimeFormat } from '@angular/common';
//import { Product } from '../../../shared/models/product';
import { Product } from '../../../../shared/models/product';
import { DealServiceService } from 'src/app/deal-service.service';
import { Seller } from 'src/app/shared/models/seller';
import { IfStmt } from '@angular/compiler';
import { dealsProduct } from 'src/app/shared/models/dealsProduct';

//import { Seller } from '../../../../shared/models/seller';
//import {DealServiceService} from './deal-service.service';

@Component({
  selector: 'app-seller-deals-for-today',
  templateUrl: './seller-deals-for-today.component.html',
  styleUrls: ['./seller-deals-for-today.component.css']
})
export class SellerDealsForTodayComponent implements OnInit {
  dealsToAdd : any;
  addNewDeal : dealsProduct;
  
  dealsAddForm: FormGroup;
  //message : string="";

  errorMessage: string = "";
  successMessage: string="";

  addProduct : Product

  @Input()
  seller: Seller;
  productCategoryList: String[];
  productList : Product[]
  displayProducts: Boolean;
 
  viewDealDetails: boolean =false;

constructor(private fb: FormBuilder,private s: DealServiceService) { }

  ngOnInit() {


    this.seller = JSON.parse(sessionStorage.getItem("seller"));
   
    this.s.getProducts(this.seller.emailId)
            .subscribe(response => {
                 this.productList = response
                this.displayProducts = this.productList.length != 0;
             })

   this.productList = JSON.parse(sessionStorage.getItem("sellerProducts"));
   this.displayProducts = true
   
   this.dealsAddForm = this.fb.group({
     
      dealDiscount: ["", Validators.required],
      dealStartsAt: ["", Validators.required],
      dealEndsAt: ["", Validators.required],

      
    });
    
  }

  showProductDetails(product)
  {
    this.addProduct=product;
    this.viewDealDetails=true;
    this.displayProducts = false;

    
  }

  addDeals() {

    //this.message = null;
    let dealProduct=new dealsProduct();
    dealProduct.product=this.addProduct;

    
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    dealProduct.sellerEmailId=this.seller.emailId;

dealProduct.dealStarts=this.dealsAddForm.controls.dealStartsAt.value;

dealProduct.dealDiscount=this.dealsAddForm.controls.dealDiscount.value;
dealProduct.dealEnds=this.dealsAddForm.controls.dealEndsAt.value;

    this.s.addToDeals(dealProduct).subscribe((response) => {               
        console.log(response);
        //this.ngOnInit();
       this.successMessage = response.successMessage 
     
      },
        error => this.errorMessage = <any>error
    )
}
}
