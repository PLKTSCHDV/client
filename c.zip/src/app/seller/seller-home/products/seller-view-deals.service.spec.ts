import { TestBed } from '@angular/core/testing';

import { SellerViewDealsService } from './seller-view-deals.service';

describe('SellerViewDealsService', () => {
  let service: SellerViewDealsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SellerViewDealsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
