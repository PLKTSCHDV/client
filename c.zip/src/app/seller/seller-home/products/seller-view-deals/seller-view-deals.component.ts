import { Component, OnInit ,Input} from '@angular/core';
import { Seller } from 'src/src/app/shared/models/seller';
import { dealsProduct } from 'src/app/shared/models/dealsProduct';
import { Product } from 'src/app/shared/models/product';
import { SellerViewDealsService } from '../seller-view-deals.service';

@Component({
  selector: 'app-seller-view-deals',
  templateUrl: './seller-view-deals.component.html',
  styleUrls: ['./seller-view-deals.component.css']
})
export class SellerViewDealsComponent implements OnInit {
 p: number = 1;
  page: boolean = false;
  isProductSelected: boolean = false;
  selectedProduct: Product;
  productOnDeals: dealsProduct[];
  errorMessage: string;
  successMessage: string;

  constructor(private viewDealsService: SellerViewDealsService) { }

  seller: Seller;
  ngOnInit() {

      this.seller = this.getSellerFromSession();
      this.errorMessage = null;
      this.productOnDeals = null;
      this.successMessage = null;

      this.getAllDeals();

  }

  getAllDeals() {
      this.viewDealsService.getDealProducts(this.seller.emailId).subscribe(
          (response) => {
              this.productOnDeals = response;
              if (this.productOnDeals.length > 10) {
                  this.page = true
              }
          },
          (response) => {
              this.errorMessage = response.error.message;
              this.productOnDeals = null;
              this.successMessage = null;
              
          }
      )
  }

  removeFromDeals(productOnDeals: dealsProduct) {
      this.successMessage = null;
      this.errorMessage = null;

      this.viewDealsService.removeProductFromDeal(productOnDeals).subscribe(
          response => {
              this.successMessage = response.toString();
              this.getAllDeals();
          },

          response => {
              this.errorMessage = response.toString();
              this.getAllDeals();
          },

      )
  }

  getSellerFromSession() {
      return JSON.parse(sessionStorage.getItem("seller"))
  }

  setSelectedProduct(product: Product) {
      this.isProductSelected = true;
      this.successMessage = null;
      this.selectedProduct = product;
  }

  unsetSelectedProduct() {
      this.isProductSelected = false;
      this.selectedProduct = null;
  }

  isDealActive(productOnDeals: dealsProduct): boolean {
      let sysDateTime: Date = new Date();
      let currHour = sysDateTime.getHours();
      let currMin = sysDateTime.getMinutes();

      let endHour = productOnDeals.dealEnds[3];
      let endMin = productOnDeals.dealEnds[4];

      if (endHour<currHour)
          return false;
      else if(endHour === currHour && endMin<currMin)
          return false;

      return true;
  }
}

/*dealList: any[]

seller: Seller
displayProducts: Boolean
productToBeViewed: Product
p: number = 1
productListLength: boolean=false
successMessage:string=""
errorMessage:string=""
page: boolean = false
constructor(private SellerDealsForTodayService: SellerViewDealsService) { }
ngOnInit() {


  // this.productList = JSON.parse(sessionStorage.getItem("sellerProducts"));
  this.displayProducts = true
  this.seller = JSON.parse(sessionStorage.getItem("seller"));
  this.getProductDeals()


}
getProductDeals() {
  console.log(this.seller.emailId)
  this.SellerDealsForTodayService.getDealProducts(this.seller.emailId)
    .subscribe(dealList => {
  
      if (dealList.length > 10) {
        this.page = true
      }
      if(dealList.length>=1){
        this.productListLength=true
      }
      else{
        this.productListLength=false
      }
      let newDealList:any=[]
      for(let deal of dealList){
       let endDate  = deal.dealEndsAt
       let endDateModified = endDate[0]+"-"+ endDate[1]+"-"+ endDate[2] + " "+ endDate[3]+":"+endDate[4]
      let todayDate = new Date()
        let endDateFinal=new Date(endDateModified)
      
       newDealList.push(deal)
      }
      this.dealList=newDealList
      console.log(this.dealList)
    }
    ,
      error=>{
        this.errorMessage=error.errorMessage
      
    }
    )
}
viewProductDetails(product: Product) {
  this.displayProducts = false
  this.productToBeViewed = product
  this.successMessage=""
  this.errorMessage=""
}
goBackToViewDeals() {
  this.displayProducts = true
  this.productToBeViewed = null
}

removeProduct(deal: any){
  console.log(deal)
  let newDeal:dealsProduct=new dealsProduct()
  newDeal.dealId=deal.dealId
  newDeal.dealDiscount=deal.dealDiscount
  newDeal.dealEndsAt=null
  newDeal.product=deal.product
  newDeal.dealStartsAt=null
  newDeal.sellerEmailId=deal.seller
  newDeal.successMessage=""
  newDeal.errorMessage=""
  console.log(newDeal)
  this.SellerDealsForTodayService.removeProductFromDeal(newDeal)
  .subscribe(
    response=>{
     this.successMessage=response.successMessage
     
      let newDealList:any[]=[]
      for(let deal1 of this.dealList){

       let endDate  = deal1.dealEndTime
       let endDateModified = endDate[0]+"-"+ endDate[1]+"-"+ endDate[2] + " "+ endDate[3]+":"+endDate[4]
      let todayDate = new Date()
        let endDateFinal=new Date(endDateModified)
      if(todayDate> endDateFinal){
         deal1.isExpired=true
      }
      else{
        deal1.isExpired= false
      }
      if(deal1.dealId!=deal.dealId) {   
       newDealList.push(deal1)}
      }
      this.dealList=newDealList
      console.log(this.dealList)

      if (this.dealList.length > 10) {
        this.page = true
      }
      if(this.dealList.length>=1){
        this.productListLength=true
      }
      else{
        this.productListLength=false
      }
    },
      error=>{
        this.errorMessage=error.errorMessage
      
    }
   
  )

}
}
*/