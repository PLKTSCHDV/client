import { Component, OnInit ,Input} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { validate } from 'json-schema';
import { endWith } from 'rxjs/operators';
import { Product } from 'src/src/app/shared/models/product';
@Component({
  selector: 'app-seller-deals',
  templateUrl: './seller-deals.component.html',
  styleUrls: ['./seller-deals.component.css']
})
export class SellerDealsComponent implements OnInit {
  @Input()
 selectedProduct: Product;

 dealPrice : number;
 constructor() {}
 
 ngOnInit() { 
    this.dealPrice = this.selectedProduct.price - (this.selectedProduct.price*this.selectedProduct.discount/100)
 }
 
 ngOnDestroy(){
 Object.assign(this.selectedProduct);
}
}
