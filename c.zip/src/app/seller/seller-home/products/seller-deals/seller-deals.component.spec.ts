import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerDealsComponent } from './seller-deals.component';

describe('SellerDealsComponent', () => {
  let component: SellerDealsComponent;
  let fixture: ComponentFixture<SellerDealsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SellerDealsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
