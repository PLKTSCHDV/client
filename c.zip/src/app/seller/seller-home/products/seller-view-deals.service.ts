import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs'
import { environment } from 'src/environments/environment';
import { dealsProduct } from 'src/app/shared/models/dealsProduct';

@Injectable({
  providedIn: 'root'
})
export class SellerViewDealsService {
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  constructor(private http:HttpClient) { }

  getDealProducts(emailId: any) {
    let url: string = environment.sellersDealAPI + "/" + emailId + "/get-deals";
    return this.http.get<dealsProduct[]>(url)
  }

  removeProductFromDeal(deal : dealsProduct): Observable<dealsProduct> {
    const url = environment.sellersDealAPI + "/delete-deal" + "/" + deal.dealId;
    console.log(JSON.stringify(deal))
    return this.http.post<dealsProduct>(url, JSON.stringify(deal), { headers: this.headers })
  }
}